import json
import pandas
from storage.pyStorage import pyStorage
import time
import os

"""
This function is required for the following parallel function mBackground 
to get the projected file names
return: - list of file names which are located in <bucket-name>/temp/[color_folder]/proj
        - number of files
"""

def handler(event):
    start_et = int(round(time.time() * 1000))

    color_folder = event.json.get('color_folder')
    bucket_arn = event.json.get('bucket')

    filename_pimages = 'temp/' + color_folder + '/pimages.tbl'
    pimages_tmp = '/tmp/pimages.tbl'
    
    pyStorage.create_cred_file(
        aws_access_key_id = event.json.get('credentials')[0],
        aws_secret_access_key = event.json.get('credentials')[1],
        aws_session_token = event.json.get('credentials')[2],
        gcp_client_email = event.json.get('credentials')[3],
        gcp_private_key = event.json.get('credentials')[4],
        gcp_project_id = event.json.get('credentials')[5]
        )
    
    start = int(round(time.time() * 1000))
    pyStorage.copy(bucket_arn + '/' + filename_pimages, pimages_tmp)
    end = int(round(time.time() * 1000))
    
    dl_time = end-start
    
    pimages_table = pandas.read_table('/tmp/pimages.tbl', skiprows=3, delim_whitespace=True, header=None, index_col=None)
    filenames = []
    
    #####
    for row in pimages_table.values:
        filenames.append(row[13].split('/tmp/proj/')[1])
    ####
    
    dt = {
        'DT': dl_time,
        'files': 1,
        'total_size': os.path.getsize(pimages_tmp)
    }
    
    ut = {
        'UT': 0,
        'files': 0,
        'total_size': 0
    }
    
    end_et = int(round(time.time() * 1000))
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': end_et-start_et
    }
    
    return {
        'statusCode': 200,
        'runtime_data' : runtime_data,
        'filenames': filenames,
        'number' : len(filenames),
        'bucket' :  event.json.get('bucket'),
        'header' : event.json.get('header'),
        'color_folder' : color_folder,
        'credentials' : event.json.get('credentials')
    }