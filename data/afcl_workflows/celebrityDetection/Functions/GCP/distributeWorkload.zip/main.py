import re

from libcloud.storage.types import Provider
from libcloud.storage.providers import get_driver


def distribute_workload(request):
    event = request.get_json()

    image_folders = event["imagepaths"]
    all_images_aws = []
    all_images_gs = []

    s3_driver = get_driver(Provider.S3)
    s3_client = s3_driver(event["aws_access_key_id"], event["aws_secret_key"], token=event["aws_session_token"])

    gc_driver = get_driver(Provider.GOOGLE_STORAGE)
    gc_client = gc_driver(key=event["gcp_client_email"], secret=event["gcp_private_key"], project=event["gcp_project_id"])

    for image_folder in image_folders:
        bucket, folder = split_path(image_folder)
        
        if bucket is None:
            return {"result": "Error. Invalid Path: " + image_folder}
            
        elif image_folder.startswith("s3://"):
            container = s3_client.get_container(container_name=bucket)
            objects = s3_client.list_container_objects(container, prefix=folder)
            for obj in objects:
                obj.name = bucket + "/" + obj.name
            all_images_aws.extend(objects)

        elif image_folder.startswith("gs://"):
            container = gc_client.get_container(container_name=bucket)
            objects = gc_client.list_container_objects(container, prefix=folder)
            for obj in objects:
                obj.name = bucket + "/" + obj.name
            all_images_gs.extend(objects)

    images = []
    for obj in all_images_aws:
        temp = "s3://" + str(obj.name)
        if (temp.endswith(".jpg") or temp.endswith(".webp") or temp.endswith(".png") or temp.endswith(".jpeg")) and "/images/" in temp:
            images.append(temp)

    for obj in all_images_gs:
        temp = "gs://" + str(obj.name)
        if (temp.endswith(".jpg") or temp.endswith(".webp") or temp.endswith(".png") or temp.endswith(".jpeg")) and "/images/" in temp:
            images.append(temp)

    return {
        "images": images, 
        "imageCount": len(images),
        "aws_access_key_id": event["aws_access_key_id"],
        "aws_secret_key": event["aws_secret_key"],
        "aws_session_token": event["aws_session_token"],
        "gcp_project_id": event["gcp_project_id"],
        "gcp_private_key": event["gcp_private_key"],
        "gcp_client_email": event["gcp_client_email"]
    }


def split_path(path: str):
    """Split an S3 or GS path in bucket and object
    
    :type path: string
    :param path: S3 or GS path with bucket and key, e.g. 's3://bucket/key'
     
    :rtype: tuple of string
    :returns: The bucket and object as a tuple: (bucket, object)
    """
    if path.startswith("s3://"):
        RE_PATH = re.compile('s3://([^/]+)/(.*)', re.IGNORECASE)
    elif path.startswith("gs://"):
        RE_PATH = re.compile('gs://([^/]+)/(.*)', re.IGNORECASE)
    else:
        return None, None
    
    # try to get components
    match = RE_PATH.match(path)
    
    # alert if the pattern did not match
    assert match is not None, 'path should be like: s3://bucket/object or gs://bucket/object'
    
    # return
    bucket, key = match.groups()
    return bucket, key 
