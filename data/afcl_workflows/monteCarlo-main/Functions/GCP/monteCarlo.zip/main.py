import handler
import json

#
# Google Cloud Functions Default Function
#
# This hander is used as a bridge to call the platform neutral version in handler.py
def main(request):
	request_json = request.get_json()
	return json.dumps(handler.monteCarlo(request_json, None))