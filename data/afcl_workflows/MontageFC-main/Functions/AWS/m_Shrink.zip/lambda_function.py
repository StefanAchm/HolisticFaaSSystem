import json
import logging
from MontagePy.main import mShrink
from storage.pyStorage import pyStorage
from Inspector import *

"""
This function executes mShrink to shrink the mosaic.fits file and uploads
shrinked file to <bucket-arn>/output/
"""

def lambda_handler(event, context):
    
    inspector = Inspector()
    inspector.inspectAll()
    bucket_arn = event['bucket']
    output_bucket = event['output_bucket']
    color_folder = event['color_folder']
    
    shrink_value = 1.5
    
    pyStorage.create_cred_file(
        aws_access_key_id = event['credentials'][0],
        aws_secret_access_key = event['credentials'][1],
        aws_session_token = event['credentials'][2],
        gcp_client_email = event['credentials'][3],
        gcp_private_key = event['credentials'][4],
        gcp_project_id = event['credentials'][5]
        )
    
    inspector.addTimeStamp("StartDownload1")
    pyStorage.copy(bucket_arn + '/output/mosaic_' + color_folder + '.fits', '/tmp/mosaic.fits')
    inspector.addTimeStamp("EndDownload1")
    
    size_download = os.path.getsize('/tmp/mosaic.fits')
    
    rtn = mShrink('/tmp/mosaic.fits', '/tmp/mosaic.fits', shrink_value)
    
    if rtn['status']=='1':
        return{
            'statusCode' : 400,
            'mShrink error: ' : rtn['msg']
        }
    
    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy('/tmp/mosaic.fits', output_bucket + '/output/mosaic_' + color_folder + '.fits')
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': 1,
        'total_size': size_download
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 1,
        'total_size': os.path.getsize('/tmp/mosaic.fits')
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn,
        'memory' : inspector.getAttribute('functionMemory')
    }
            
    return {
        'statusCode': 200,
        'bucket' : bucket_arn,
        'color_folder' : color_folder,
        'credentials': event['credentials'],
        'runtime_data' : runtime_data
    }
