import json
import os
import subprocess
from Inspector import *
from storage.pyStorage import pyStorage
import time


def lambda_handler(event, context):
    start_all = int(round(time.time() * 1000))
    
    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])


    chunk_file = event["fastaIndexed"]
    download_chunk_folder = event["chunk_folder"]
    chunk_folder = pyStorage.retrieve_file_name(download_chunk_folder)
    r_file = event['R2']
    bucket =  event["output_buckets"][3]

    result_dict = {}
    
    start_all_dls = int(round(time.time() * 1000))
    
    # Load chunk
    start = int(round(time.time() * 1000))
    result = pyStorage.copy(chunk_file, '/tmp/chunk.fasta')
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta"] = (end - start)

    # Load R1 or R2
    start = int(round(time.time() * 1000))
    result = pyStorage.copy(r_file, '/tmp/R2.fq')
    end = int(round(time.time() * 1000))
    result_dict["dl_R2.fq"] = (end - start)
   
    files_to_download = [
        "chunk.fasta.amb",
        "chunk.fasta.ann",
        "chunk.fasta.bwt",
        "chunk.fasta.pac",
        "chunk.fasta.sa"
    ]

    # Load index files
    for file in files_to_download:
        start = int(round(time.time() * 1000))
        pyStorage.copy(download_chunk_folder + file, "/tmp/" + file)
        end = int(round(time.time() * 1000))
        dict_key = "dl_" + file
        result_dict[dict_key] = (end - start)
        
    end_all_dls = int(round(time.time() * 1000))
    result_dict["dl_ALL"] = (end_all_dls - start_all_dls)
    
    start_work = int(round(time.time() * 1000))

    # Index chunk
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print("Showing content after file load", result)

    print('./bwa aln /tmp/chunk.fasta /tmp/R2.fq -f /tmp/aln_saiR2.sai')
    result = subprocess.check_output(
        './bwa aln /tmp/chunk.fasta /tmp/R2.fq -f /tmp/aln_saR2.sai', shell=True).decode(
        'ASCII')
    print(result)

    alignment_file = bucket + chunk_folder + 'aln_saR2.sai'
    
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)
    
    end_work = int(round(time.time() * 1000))
    result_dict["work_ALL"] = (end_work - start_work)
    
    # Store new file
    start = int(round(time.time() * 1000))
    pyStorage.copy('/tmp/aln_saR2.sai', alignment_file)
    end = int(round(time.time() * 1000))
    result_dict["up_aln_saR2.sai"] = (end - start)
    result_dict["up_ALL"] = (end - start)
    
    result_dict["aln2"] = alignment_file
    result_dict["output_buckets"] = event["output_buckets"]
    result_dict["aws_access_key_id"] = event["aws_access_key_id"]
    result_dict["aws_secret_key"] = event["aws_secret_key"]
    result_dict["aws_session_token"] = event["aws_session_token"]
    result_dict["gcp_client_email"] = event["gcp_client_email"]
    result_dict["gcp_private_key"] = event["gcp_private_key"]
    result_dict["gcp_project_id"] = event["gcp_project_id"]
    result_dict["chunk_folder"] = event["chunk_folder"]

    end_all = int(round(time.time() * 1000))
    result_dict["work_ALL"] = (end_all - start_all) - result_dict["dl_ALL"] - result_dict["up_ALL"]

    return result_dict
