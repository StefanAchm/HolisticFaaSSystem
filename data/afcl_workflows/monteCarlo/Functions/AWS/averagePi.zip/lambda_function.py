import handler

#
# AWS Lambda Default Function
#
# This hander is used as a bridge to call the platform neutral version in handler.py
def lambda_handler(request, context):
    return handler.averagePi(request, context)
