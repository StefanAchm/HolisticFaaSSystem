import json
import boto3
from Inspector import *

"""
This function is required for the following parallel function mProjectPP 
to get the input file names
return: - list of file names which are located in <bucket-arn>/input/color_folder/
        - number of files
"""

def lambda_handler(event, context):
    
    inspector = Inspector()
    inspector.inspectAll()

    s3 = boto3.resource('s3')
    bucket_name = event['bucket'][len("arn:aws:s3:::"):].split("/")[0]
    bucket = s3.Bucket(bucket_name)
    color_folder = event['color_folder']
    
    file_names = []

    #input files needs to be located at <bucket-name>/input
    for file in bucket.objects.filter(Prefix="input/"+ color_folder + "/"):
        file_name = file.key.split("input/")[1]
        if file_name[-5:] == '.fits' and file_name != "" :
            file_names.append(file_name)
          
    inspector.finish()
    
    dt = {
        'DT': 0,
        'files': 0,
        'total_size': 0
    }
    
    ut = {
        'UT': 0,
        'files': 0,
        'total_size': 0
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': event['bucket'],
        'memory' : inspector.getAttribute('functionMemory')
    }
    
    return {
        'statusCode': 200,
        'runtime_data' : runtime_data,
        'filenames': file_names,
        'number' : len(file_names),
        'bucket' :  event['bucket'],
        'header' : event['header'],
        'color_folder' : color_folder,
        'credentials' : event['credentials']
    }
