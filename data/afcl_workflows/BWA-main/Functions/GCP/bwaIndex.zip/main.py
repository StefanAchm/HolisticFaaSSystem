import subprocess
import os
import json
from Inspector import *
from storage.pyStorage import pyStorage
from storage.pyUrlParser import pyUrlParser
import time

def main(request):
    event = request.get_json()
    start_all = int(round(time.time() * 1000))
    
    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])


    fast_file = event["fasta"]
    tmp_folder = pyStorage.retrieve_file_name(event["fasta"])
    chunk_folder = "/".join(tmp_folder.split("/")[:-1]) + "/"
    print("Using fast_file: {}".format(fast_file))
    
    bucket = event["output_buckets"][1]
    
    result_dict = {}

    # Load chunk
    start = int(round(time.time() * 1000))
    result = pyStorage.copy(fast_file, '/tmp/chunk.fasta')
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta"] = (end - start)
    result_dict["dl_ALL"] = (end - start)

    # Index chunk
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)

    result = subprocess.check_output('./bwa index /tmp/chunk.fasta', shell=True).decode('ASCII')
    print(result)

    files_to_store = [
        "chunk.fasta.amb",
        "chunk.fasta.ann",
        "chunk.fasta.bwt",
        "chunk.fasta.pac",
        "chunk.fasta.sa"
    ]

    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)

    start_all_ups = int(round(time.time() * 1000))

    for file in files_to_store:
        # Store new files
        tmp_file = '/tmp/' + file
        target_file = bucket + chunk_folder + file
        print("Writing tmp file: {} to s3: {}".format(tmp_file, target_file))
        start = int(round(time.time() * 1000))
        pyStorage.copy(tmp_file,  target_file.strip())
        end = int(round(time.time() * 1000))
        dict_key = "up_" + file
        result_dict[dict_key] = (end - start)
        
    end_all_ups = int(round(time.time() * 1000))
    result_dict["up_ALL"] = (end_all_ups - start_all_ups)
    
    result_dict["fastaIndexed"] = fast_file
    result_dict["output_buckets"] = event["output_buckets"]
    result_dict["aws_access_key_id"] = event["aws_access_key_id"]
    result_dict["aws_secret_key"] = event["aws_secret_key"]
    result_dict["aws_session_token"] = event["aws_session_token"]
    result_dict["gcp_client_email"] = event["gcp_client_email"]
    result_dict["gcp_private_key"] = event["gcp_private_key"]
    result_dict["gcp_project_id"] = event["gcp_project_id"]
    result_dict["chunk_folder"] = bucket + chunk_folder
    
    end_all = int(round(time.time() * 1000))
    result_dict["work_ALL"] = (end_all - start_all) - result_dict["dl_ALL"] - result_dict["up_ALL"]

    return result_dict
