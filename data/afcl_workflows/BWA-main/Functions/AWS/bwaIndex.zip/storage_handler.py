import boto3
import botocore


def load_file(bucket, file, tmp_path): 
    s3 = boto3.resource('s3')

    print("Loading file {} from bucket {} to {}".format(file, bucket, tmp_path))

    try:
        s3.Bucket(bucket).download_file(file, tmp_path)
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            msg = "The object does not exist."
        else:
            msg = "Unexpected error: %s" % e
        raise Exception(msg)



def store_file(bucket, file, tmp_path):
    s3 = boto3.resource('s3')

    print("Storing file {} into bucket {} from {}".format(file, bucket, tmp_path))

    try:
        s3.Bucket(bucket).upload_file(tmp_path, file)
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            msg = "The object does not exist."
        else:
            msg = "Unexpected error: %s" % e
        raise Exception(msg)
        
