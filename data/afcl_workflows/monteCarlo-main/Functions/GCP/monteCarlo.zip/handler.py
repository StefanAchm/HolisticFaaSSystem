import json
import logging
from Inspector import *
import time
import os
import random

#
# Define your FaaS Function here.
# Each platform handler will call and pass parameters to this function.
# 
# @param request A JSON object provided by the platform handler.
# @param context A platform specific object used to communicate with the cloud platform.
# @returns A JSON object to use as a response.
#
def monteCarlo(request, context):
    # Import the module and collect data
    inspector = Inspector()
    inspector.inspectAll()
    
    if ("functionName" in os.environ):
        inspector.addAttribute("userData_functionName", os.environ.get("functionName"))
    elif ("functionName" in request):
        inspector.addAttribute("userData_functionName", request["functionName"])
        
    if ("num_samples" in request):
        inspector.addAttribute("userData_num_samples", request["num_samples"])
        
        samples = []
        for i in range(int(request["num_samples"])):
            rand_x = random.uniform(-1, 1)
            rand_y = random.uniform(-1, 1)
            
            distance = (rand_x * rand_x) + (rand_y * rand_y)
            samples.append(distance)
        
        circle_points = float(0)
        square_points = float(0)
        for i in samples:
            square_points += 1 #total number of points
            if (i <= 1):
                circle_points += 1 #number of points in the unity circle            
        
        pi = float(0)
        if (square_points > 0):
            pi = (float(4) * circle_points) / square_points;

        inspector.addAttribute("userData_result", pi)
        inspector.addAttribute("userData_squarePoints", square_points)
        inspector.addAttribute("userData_circlePoints", circle_points)
        
    inspector.inspectAllDeltas()
    return inspector.finish()
