import os
import wikipedia

from google.cloud import translate_v2 as translate
from storage.pyStorage import pyStorage

def summary_translate(request):
    event = request.get_json()

    celebrity_folder = event["celebrityFolder"].rstrip("/")
    folder_name = os.path.basename(celebrity_folder)
    # Whitespaces were replaced with underscores in a previous function
    celebrity = folder_name.replace("_", " ")
    rick_roll = False

    try:
        summary = wikipedia.summary(celebrity)
    except (wikipedia.exceptions.PageError, wikipedia.exceptions.DisambiguationError):
        summary = wikipedia.summary("Rick Astley")
        rick_roll = True

    translate_client = translate.Client()
    de_result = translate_client.translate(summary, source_language="en", target_language="de")
    de_summary = de_result["translatedText"]

    local_filename = "/tmp/summary.txt"

    with open(local_filename, 'w') as text_file:
        if rick_roll:
            text_file.write('Nothing could be found about this celebrity.\n')
            text_file.write('Let me tell you something about Rick Astley instead.\n\n')

        text_file.write('Original:\n')
        text_file.write(summary)
        text_file.write('\n\nTranslated:\n')
        text_file.write(de_summary)

    # upload
    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])

    remote_file = celebrity_folder + '/summary.txt'

    pyStorage.copy(local_filename, remote_file)  
    
    return {
        'celebrityFolder': celebrity_folder
    }
