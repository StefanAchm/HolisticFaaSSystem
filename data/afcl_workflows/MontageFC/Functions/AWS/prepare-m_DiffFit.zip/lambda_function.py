import json
from MontagePy.main import mImgtbl, mOverlaps
import boto3
import os
import pandas
from storage.pyStorage import pyStorage
from subprocess import call
from Inspector import *

"""
This function is required for the following parallel function mDiffFit.
Generates a list of differences from diffs.tbl. Uploads pimages.tbl and diffs.tbl
return: - list of diff rows
        - number of files
"""
def get_dir_size(path='.'):
    total = 0
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    return total
    
    
def deleteTmp():
    call('rm -rf /tmp/*', shell=True)
    
def lambda_handler(event, context):
    
    deleteTmp()
    inspector = Inspector()
    inspector.inspectAll()
    
    os.mkdir('/tmp/input')
    
    s3 = boto3.client("s3")
    bucket_arn = event['bucket']
    output_bucket = event['output_bucket']
    
    bucket_name = event['bucket'][len("arn:aws:s3:::"):].split("/")[0]
    color_folder = event['color_folder']
    header = event['header']
    header_tmp = '/tmp/' + header
    header_path = 'input/' + header
 
    #response = s3.list_objects_v2(
    #    Bucket=bucket_name, Prefix='temp/' + color_folder + '/' + 'proj/')
        
    #s3_files = response["Contents"]
    
    ###
    paginator = s3.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=bucket_name, Prefix='input/' + color_folder + '/')
    ###
    
    pyStorage.create_cred_file(
        aws_access_key_id = event['credentials'][0],
        aws_secret_access_key = event['credentials'][1],
        aws_session_token = event['credentials'][2],
        gcp_client_email = event['credentials'][3],
        gcp_private_key = event['credentials'][4],
        gcp_project_id = event['credentials'][5]
        )
    
    inspector.addTimeStamp("StartDownload1")
    pyStorage.copy(bucket_arn + '/' + header_path, header_tmp)
    count_files_download = 1

    for page in pages:
        if "Contents" in page:
            for obj in page['Contents']:
                if obj["Key"][-5:] == '.fits':
                    pyStorage.copy(bucket_arn + '/' + obj["Key"], '/tmp/input/{}'.format(obj["Key"].split('input/' + color_folder + '/')[1]))
                    count_files_download = count_files_download + 1

    #for s3_file in s3_files:
        ##Key: /temp/proj/file_name
        #if s3_file["Key"][-10:] == '_area.fits':
        #    continue
        #pyStorage.copy(bucket_arn + '/' + s3_file["Key"], '/tmp/{}'.format(s3_file["Key"].split('temp/' + color_folder + '/')[1]))
        #count_files_download = count_files_download + 1
    
    inspector.addTimeStamp("EndDownload1")
    size_download = get_dir_size('/tmp/')
    
    rtn = mImgtbl('/tmp/input', '/tmp/images.tbl') 
    
    if rtn['status']=='1':
        return{
            'statusCode' : 400,
            'mImgtbl error: ' : rtn['msg']
        }
    
    rtn_mDAG = call(["/opt/bin/mDAGTbls", "/tmp/images.tbl", header_tmp, "/tmp/rimages.tbl", "/tmp/pimages.tbl", "/tmp/cimages.tbl"])
    
    rtn = mOverlaps("/tmp/pimages.tbl", "/tmp/diffs.tbl")
    
    if rtn['status']=='1':
        return{
            'statusCode' : 400,
            'mOverlaps error: ' : rtn['msg']
        }
        
    ###########pimages
    with open('/tmp/pimages.tbl', 'r') as file:
        filedata = file.read()
    # Replace the target string
    filedata = filedata.replace('p2mass', '/tmp/proj/2mass')
    filedata = filedata.replace('                               file', '                                        file')
    filedata = filedata.replace('                               char', '                                        char')

    # Write the file out again
    with open('/tmp/pimages.tbl', 'w') as file:
        file.write(filedata)
        
    ###########diffs
    with open('/tmp/diffs.tbl', 'r') as file:
        filedata = file.read()
    # Replace the target string
    filedata = filedata.replace('p2mass', '/tmp/proj/2mass')
    filedata = filedata.replace('                              plus ', '                                       plus ')
    filedata = filedata.replace('                             minus ', '                                      minus ')
    filedata = filedata.replace('                              char ', '                                       char ')

    # Write the file out again
    with open('/tmp/diffs.tbl', 'w') as file:
        file.write(filedata)
    
    diff_table = pandas.read_table('/tmp/diffs.tbl', skiprows=2, delim_whitespace=True, header=None, index_col=None)
    diff_rows = []
    
    #####
    for row in diff_table.values:
        diff_row = json.dumps({
            "first_index": row[0],
            "second_index": row[1],
            "first": row[2].split('/tmp/proj/')[1],
            "second": row[3].split('/tmp/proj/')[1],
        })
        diff_rows.append(diff_row)
    ####
    
    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy('/tmp/pimages.tbl', output_bucket + '/temp/' + color_folder + '/' + 'pimages.tbl')
    pyStorage.copy('/tmp/diffs.tbl', output_bucket + '/temp/' + color_folder + '/' + 'diffs.tbl')
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': count_files_download,
        'total_size': size_download
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 2,
        'total_size': (os.path.getsize('/tmp/pimages.tbl') + os.path.getsize('/tmp/diffs.tbl'))
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn,
        'memory' : inspector.getAttribute('functionMemory')
    }
    
    return {
        'statusCode': 200,
        'runtime_data' : runtime_data,
        'diff_rows': diff_rows,
        'number': len(diff_table),
        'bucket' : bucket_arn,
        'header' : event['header'],
        'color_folder' : color_folder,
        'credentials': event['credentials']
    }
