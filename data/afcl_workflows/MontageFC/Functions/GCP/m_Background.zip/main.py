import json
import os
from storage.pyStorage import pyStorage
from subprocess import call
from Inspector import *

"""
This function exercutes mBackground and uploads the corrected
fits file to <bucket-arn>/temp/[color_folder]/correct
return: - corrected file name
        - bucket-name
"""
def get_dir_size(path='.'):
    total = 0
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    return total
    
def handler(event): 
    
    call('rm -rf /tmp/*', shell=True)
    inspector = Inspector()
    os.mkdir('/tmp/proj')
    
    file_name = event.json.get("filename")
    bucket_arn = event.json.get('bucket')
    output_bucket = event.json.get('output_bucket')
    color_folder = event.json.get('color_folder')
   
    projected ='temp/' + color_folder + '/proj/' + file_name
    projected_tmp = '/tmp/proj/' + file_name
   
    projected_area = projected[:len(projected) - 5] + '_area.fits'
    projected_area_tmp = '/tmp/proj/' + projected_area.split('/')[-1]    #split to only get filename
    
    corrected_output = file_name[:len(file_name) - 5] + "_corrected.fits"
    corrected_output_tmp = '/tmp/' + corrected_output
    
    pimages = 'temp/' + color_folder + '/pimages.tbl'
    pimages_tmp = '/tmp/pimages.tbl'
    
    corrections = 'temp/' + color_folder + '/corrections.tbl'
    corrections_tmp = '/tmp/corrections.tbl'
    
    pyStorage.create_cred_file(
        aws_access_key_id = event.json.get('credentials')[0],
        aws_secret_access_key = event.json.get('credentials')[1],
        aws_session_token = event.json.get('credentials')[2],
        gcp_client_email = event.json.get('credentials')[3],
        gcp_private_key = event.json.get('credentials')[4],
        gcp_project_id = event.json.get('credentials')[5]
        )
        
    inspector.addTimeStamp("StartDownload1")
    
    pyStorage.copy(bucket_arn + '/' + projected, projected_tmp)   
    pyStorage.copy(bucket_arn + '/' + projected_area, projected_area_tmp)  
    pyStorage.copy(bucket_arn + '/' + pimages, pimages_tmp)  
    pyStorage.copy(bucket_arn + '/' + corrections, corrections_tmp)  
    
    inspector.addTimeStamp("EndDownload1")
    size_download = get_dir_size('/tmp/')
    
    status_file_tmp = '/tmp/statusfile.txt'
    
    rtn = call(["/workspace/bin/mBackground", "-t", "-s", status_file_tmp, projected_tmp, corrected_output_tmp, pimages_tmp, corrections_tmp])

    if rtn == 1:
        file = open(status_file_tmp, "r")
        file_contents = file.read()
        file.close()
        return{
            'statusCode' : 400,
            'mBackground error: ' : file_contents
        }
    
    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy(corrected_output_tmp, output_bucket + '/temp/' + color_folder + '/correct/{}'.format(corrected_output))

    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': 4,
        'total_size': size_download
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 1,
        'total_size': os.path.getsize(corrected_output_tmp)
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_arn
    }
    
    return{
        'statusCode': 200,
        'corrected': json.dumps(corrected_output),
        'bucket' : bucket_arn,
        'color_folder': color_folder,
        'credentials': event.json.get('credentials'),
        'runtime_data' : runtime_data
    }
