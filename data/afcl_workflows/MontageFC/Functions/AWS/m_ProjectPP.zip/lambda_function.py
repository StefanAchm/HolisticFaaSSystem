import json
from storage.pyStorage import pyStorage
from MontagePy.main import mProjectPP, mProject
from subprocess import call
import os
from Inspector import *

"""
This function executes mProjectPP on the input file and uploads the projected
fits file and the _area fits file on <bucket-arn>/temp/[color_folder]/proj/
return: - projected file name
"""
def get_dir_size(path='.'):
    total = 0
    with os.scandir(path) as it:
        for entry in it:
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    return total
    
    
def deleteTmp():
    call('rm -rf /tmp/*', shell=True)
    
def lambda_handler(event, context):

    deleteTmp()
    inspector = Inspector()
    inspector.inspectAll()
    
    bucket_name = event['bucket']
    output_bucket = event['output_bucket']

    input_file = event['filename']
    header = event['header']
    
    color_folder = event['color_folder']
    input_file_wo_path = input_file.split(color_folder + "/")[1]

    #projected_file: same name as the input file
    projected_file = input_file_wo_path
    projected_file_area = projected_file[:len(projected_file) - 5] + "_area.fits"

    input_file_path = 'input/' + input_file
    header_path = 'input/' + header

    input_file_tmp = '/tmp/' + input_file_wo_path
    header_tmp = '/tmp/' + header
    
    projected_file_tmp = '/tmp/' + projected_file
    projected_file_area_tmp = '/tmp/' + projected_file_area
    
    pyStorage.create_cred_file(
        aws_access_key_id = event['credentials'][0],
        aws_secret_access_key = event['credentials'][1],
        aws_session_token = event['credentials'][2],
        gcp_client_email = event['credentials'][3],
        gcp_private_key = event['credentials'][4],
        gcp_project_id = event['credentials'][5]
        )
    
    inspector.addTimeStamp("StartDownload1")
    
    pyStorage.copy(bucket_name + '/' + input_file_path, input_file_tmp)
    pyStorage.copy(bucket_name  + '/' + header_path, header_tmp)
    
    inspector.addTimeStamp("EndDownload1")
    size_download = get_dir_size('/tmp/')
    
    rtn_PPP = mProjectPP(input_file_tmp, projected_file_tmp, header_tmp, expand=True)

    if rtn_PPP['status']=='1':
        download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
        inspector.finish()
        dt = {
            'DT': download_time/1000,
            'files': 2,
            'total_size': size_download
        }
        
        ut = {
            'UT': 0,
            'files': 0,
            'total_size': 0
        }
        
        runtime_data = {
            'download': dt,
            'upload': ut,
            'ET': inspector.getAttribute('runtime')/1000,
            'URL': bucket_name,
            'memory' : inspector.getAttribute('functionMemory')
        }
        return{
            'statusCode': 200,
            'color_folder': color_folder,
            'credentials': event['credentials'],
            'runtime_data' : runtime_data
        }
        #file = open(projected_file_tmp, "w")
        #file2 = open(projected_file_area_tmp, "w")
    
    inspector.addTimeStamp("StartUpload1")
    
    pyStorage.copy(projected_file_tmp, output_bucket + '/temp/' + color_folder + "/" + 'proj/{}'.format(projected_file))
    pyStorage.copy(projected_file_area_tmp, output_bucket + '/temp/' + color_folder + "/" + 'proj/{}'.format(projected_file_area))
    
    inspector.addTimeStamp("EndUpload1")
    
    upload_time = inspector.getAttribute('EndUpload1') - inspector.getAttribute('StartUpload1')
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': 2,
        'total_size': size_download
    }
    
    ut = {
        'UT': upload_time/1000,
        'files': 2,
        'total_size': (os.path.getsize(projected_file_tmp) + os.path.getsize(projected_file_area_tmp))
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': bucket_name,
        'memory' : inspector.getAttribute('functionMemory')
    }
    
    
    return{
        'statusCode': 200,
        'projected' : projected_file,
        'color_folder': color_folder,
        'credentials': event['credentials'],
        'runtime_data' : runtime_data
    }