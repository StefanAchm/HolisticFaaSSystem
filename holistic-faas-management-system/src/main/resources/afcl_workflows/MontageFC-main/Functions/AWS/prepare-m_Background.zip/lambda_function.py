import json
import boto3
from Inspector import *
import pandas
from storage.pyStorage import pyStorage

"""
This function is required for the following parallel function mBackground 
to get the projected file names
return: - list of file names which are located in <bucket-name>/temp/[color_folder]/proj
        - number of files
"""

def lambda_handler(event, context):

    inspector = Inspector()
    inspector.inspectAll()
    s3 = boto3.resource('s3')
    bucket_arn = event['bucket']
    color_folder = event['color_folder']
    
    filename_pimages = 'temp/' + color_folder + '/pimages.tbl'
    pimages_tmp = '/tmp/pimages.tbl'
    
    pyStorage.create_cred_file(
        aws_access_key_id = event['credentials'][0],
        aws_secret_access_key = event['credentials'][1],
        aws_session_token = event['credentials'][2],
        gcp_client_email = event['credentials'][3],
        gcp_private_key = event['credentials'][4],
        gcp_project_id = event['credentials'][5]
        )
    
    inspector.addTimeStamp("StartDownload1")
    pyStorage.copy(bucket_arn + '/' + filename_pimages, pimages_tmp)
    inspector.addTimeStamp("EndDownload1")
    
    download_time = inspector.getAttribute('EndDownload1') - inspector.getAttribute('StartDownload1')
    
    pimages_table = pandas.read_table('/tmp/pimages.tbl', skiprows=3, delim_whitespace=True, header=None, index_col=None)
    filenames = []
    
    #####
    for row in pimages_table.values:
        filenames.append(row[13].split('/tmp/proj/')[1])
    ####
    
    #filenames = []

    #for file in bucket.objects.filter(Prefix='temp/' + color_folder + '/proj/'):
    #    file_name = file.key.split('temp/' + color_folder + '/proj/')[1]
    #    if file_name[-10:] != '_area.fits':
    #        filenames.append(file_name)
            
    inspector.finish()
    
    dt = {
        'DT': download_time/1000,
        'files': 1,
        'total_size': os.path.getsize(pimages_tmp)
    }
    
    ut = {
        'UT': 0,
        'files': 0,
        'total_size': 0
    }
    
    runtime_data = {
        'download': dt,
        'upload': ut,
        'ET': inspector.getAttribute('runtime')/1000,
        'URL': event['bucket'],
        'memory' : inspector.getAttribute('functionMemory')
    }
    
    
    return {
        'statusCode': 200,
        'runtime_data' : runtime_data,
        'filenames': filenames,
        'number' : len(filenames),
        'bucket' : event['bucket'],
        'header' : event['header'],
        'color_folder' : color_folder,
        'credentials': event['credentials']
    }