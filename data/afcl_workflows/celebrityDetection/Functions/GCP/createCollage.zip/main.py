from PIL import Image
import os
import math
import re
from storage.pyStorage import pyStorage
from libcloud.storage.types import Provider
from libcloud.storage.providers import get_driver

def collage(request):
    event = request.get_json()

    dst_bucket = event["celebrityFolder"]            
    directory = os.path.join(dst_bucket, "crops")

    pyStorage.create_cred_file(
        aws_access_key_id=event['aws_access_key_id'],
        aws_secret_key=event['aws_secret_key'],
        aws_session_token=event['aws_session_token'],
        gcp_client_email=event['gcp_client_email'],
        gcp_private_key=event['gcp_private_key'],
        gcp_project_id=event['gcp_project_id']
    )

    image_list = download_images(directory, event)
    create_collage(800, 800, image_list, dst_bucket)

    return {
        "celebrityFolder" : dst_bucket,
        "aws_access_key_id": event["aws_access_key_id"],
        "aws_secret_key": event["aws_secret_key"],
        "aws_session_token": event["aws_session_token"],
        "gcp_project_id": event["gcp_project_id"],
        "gcp_private_key": event["gcp_private_key"],
        "gcp_client_email": event["gcp_client_email"]
    }


def create_collage(width, height, image_list, dst_bucket_folder):
  cols = math.ceil(math.sqrt(len(image_list)))
  rows = math.ceil(math.sqrt(len(image_list)))

  for i in range (rows, 0, -1):
    if (i*cols) >= len(image_list):
      rows = i
    else:
      break

  thumbnail_width = width//cols
  thumbnail_height = height//rows
  size = thumbnail_width, thumbnail_height
  new_im = Image.new("RGB", (width, height))
  images = []
  for p in image_list:
    im = Image.open(p)
    im.thumbnail(size)
    images.append(im)
  i = 0
  x = 0
  y = 0
  for col in range(cols):
    for row in range(rows):
      if i < len(image_list):
        new_im.paste(images[i], (x, y))
        i += 1
        y += thumbnail_height
    x += thumbnail_width
    y = 0

  local_filename = "Collage.jpg"
  local_file = "/tmp/" + local_filename

  new_im.save(local_file)
  pyStorage.copy(local_file, os.path.join(dst_bucket_folder, local_filename))


def split_path(path: str):

    if path.startswith("s3://"):
        RE_PATH = re.compile('s3://([^/]+)/(.*)', re.IGNORECASE)
    elif path.startswith("gs://"):
        RE_PATH = re.compile('gs://([^/]+)/(.*)', re.IGNORECASE)
    else:
        return None, None

    # try to get components
    match = RE_PATH.match(path)

    # alert if the pattern did not match
    assert match is not None, "path should be like: s3://bucket/object or gs://bucket/object"

    # return
    bucket, key = match.groups()
    return bucket, key


def download_images(celebrity_folder, event):

    bucket, folder = split_path(celebrity_folder)

    if celebrity_folder.startswith("s3://"):
        driver = get_driver(Provider.S3)
        client = driver(event["aws_access_key_id"], event["aws_secret_key"], token=event["aws_session_token"])
    elif celebrity_folder.startswith("gs://"):
        driver = get_driver(Provider.GOOGLE_STORAGE)
        client = driver(key=event["gcp_client_email"], secret=event["gcp_private_key"], project=event["gcp_project_id"])

    container = client.get_container(container_name=bucket)
    objects = client.list_container_objects(container, prefix=folder)

    list = []

    directory = "/tmp/" + folder + "/"

    if not os.path.exists(directory):
      os.makedirs(directory)

    for obj in objects:
        filename = obj.name
        if filename.endswith(".jpg") or filename.endswith(".webp") or filename.endswith(".png") or filename.endswith(".jpeg"):
            file = "/tmp/" + filename
            if celebrity_folder.startswith("s3"):
                bucket_name = "s3://" + bucket
            else:
                bucket_name = "gs://" + bucket

            pyStorage.copy(os.path.join(bucket_name, filename), file)
            list.append(file)

    return list
